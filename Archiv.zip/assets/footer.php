<div class="footer">
    
    <div class="contentBox1">
<center>
    <a href="<?php echo $impressum; ?>" style="color:white;">Impressum </a> ⎢
        <a href="<?php echo $datenschutz; ?>" style="color:white;">Datenschutz </a>⎢
        <a href="<?php echo $agb; ?>" style="color:white;">AGB </a>
        <br>
    <br>
    aurum Helpdesk für Epic-Playing.de 

    </center>
</div>